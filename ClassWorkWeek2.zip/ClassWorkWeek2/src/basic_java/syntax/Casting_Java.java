package basic_java.syntax;

public class Casting_Java {
	
	public static void main(String[] args) {
		
		//Widening Casting
		int myInt = 7; 
		double myDouble = myInt;
		
		System.out.println(myInt);
		System.out.println(myDouble);
		
		//Narrowing Casting
		double numDouble = 8.48d;
		int numInt = (int) numDouble;
		
		System.out.println(numDouble);
		System.out.println(numInt);
	}

}
