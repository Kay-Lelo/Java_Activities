package basic_java.syntax;

import javax.swing.JOptionPane;

public class Class_Project {
	
	public static void main(String[] args) {
		
		String yourGrade = JOptionPane.showInputDialog("Enter your grade");
		int grade = Integer.parseInt(yourGrade);
		
		if (grade <=50 && grade >= 60) {
			
			System.out.println("Fail"); 
			
		} else if (grade > 60 && grade <= 70) {
			System.out.println("Your grade is D");
			
		}else if (grade > 70 && grade <= 80) {
			System.out.println("Your grade is C");
			
		}else if (grade > 80 && grade <= 90) {
			System.out.println("Your grade is B");
			
		}else if (grade >90  && grade <= 100) {
			System.out.println("Your grade is A");
			
		}
		
	
		
		
		
	}

}
