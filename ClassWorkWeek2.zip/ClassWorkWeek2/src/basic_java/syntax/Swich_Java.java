package basic_java.syntax;

public class Swich_Java {
	
	public static void main(String[] args) {
		
		int shop = 3;
		
		switch (shop) {
		
		case 1: 
			System.out.println("Lovisa");
		case 2:
			System.out.println("Mr Price");
		case 3:
			System.out.println("H&M");
		case 4:
			System.out.println("Factory");
		default:
			System.out.println("");
		}
	}

}
