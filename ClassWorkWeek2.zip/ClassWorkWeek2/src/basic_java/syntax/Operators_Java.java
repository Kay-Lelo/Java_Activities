package basic_java.syntax;

public class Operators_Java {
	
	public static void main(String[] args) {
		/*
		 * int sum1, sum2, sum3;
		 * 
		 * sum1 = 16 + 72; sum2 = sum1 + 20; sum3 = sum2 + 5;
		 * 
		 * System.out.println("Answer sum 1: " + sum1 + "\nAnswer sum 2: " + sum2 +
		 * "\nAnswer sum 3: " + sum3 );
		 */
		
		//Comparison Operators
		
		int jm , rm;
		jm = 27;
		rm = 29; 
		
		if (rm > jm) {
			
			System.out.println("Namjoon is older than Jimin!!! Saranghae");
			
		} else {
			System.out.println("You don't know BTS my G!!! Eottoke");

		}
		
	}
}
