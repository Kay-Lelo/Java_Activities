package basic_java.syntax;

public class HelloJava {
	
	public static void main(String[] args) {
//		System.out.println("Hello Java");
//		System.out.println("This is your user Tshabalala");
//		System.out.print("I'm learning Java ");
//		System.out.print("I'm a developer");
		
		//Error
		
		//System.out.println(This is Java error);
		
		//Java output number
		System.out.println(5+5);
//		System.out.println(100);
//		System.out.println(1000000);
		
		System.out.println(3/2);
		System.out.println(50/5);
		System.out.println(9 % 2);
		System.out.println(100 - 30);
	}

}
