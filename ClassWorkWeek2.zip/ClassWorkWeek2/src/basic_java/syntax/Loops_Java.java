package basic_java.syntax;

public class Loops_Java {
	
	public static void main(String[] args) {
		
		int num = 0;
		
		do {
			
			System.out.println(num);
			num++;
		} 
		
		while (num <= 10); 
		
	}

}
